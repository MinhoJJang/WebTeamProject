# v1.9.1

about.jsp, board.jsp, contact.jsp, contactMsg.jsp, main.jsp, portfolio.jsp, signup.jsp, write.jsp 일부수정

portfolio.jsp 에서 댓글 delete 위치 오른쪽 끝으로 수정

board.jsp에서 포트폴리오 두줄배치 수정

페이지들에 있는 Lorem Ipsum 글귀 수정
